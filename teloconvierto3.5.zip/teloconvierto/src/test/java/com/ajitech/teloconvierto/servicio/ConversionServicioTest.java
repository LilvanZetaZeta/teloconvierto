package com.ajitech.teloconvierto.servicio;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ConversionServicioTest {

    @Autowired
    private ConversionServicio conversionServicio;

    @MockBean
    private ConversionRepositorio conversionRepositorio;

    private Conversion crearConversion() {
        Conversion c = new Conversion();
        c.setId(1);

        Usuario usuario = new Usuario();
        usuario.setId(1);
        usuario.setNombreUsuario("usuario1");

        Archivo archivo = new Archivo();
        archivo.setId(1);
        archivo.setNombreArchivo("archivo1");

        Formato formato = new Formato();
        formato.setId(1);
        formato.setNombreFormato("formato1");
        formato.setExtensionFormato("ext");

        c.setUsuario(usuario);
        c.setArchivoOrigen(archivo);
        c.setFormatoConvertido(formato);

        return c;
    }

    @Test
    public void testListar() {
        when(conversionRepositorio.findAll()).thenReturn(List.of(crearConversion()));
        List<Conversion> conversiones = conversionServicio.listar();
        assertNotNull(conversiones);
        assertEquals(1, conversiones.size());
    }

    @Test
    public void testObtenerPorId() {
        Conversion conversion = crearConversion();
        when(conversionRepositorio.findById(1)).thenReturn(Optional.of(conversion));
        Conversion found = conversionServicio.obtenerPorId(1);
        assertNotNull(found);
        assertEquals(1, found.getId());
    }

    @Test
    public void testGuardar() {
        Conversion conversion = crearConversion();
        when(conversionRepositorio.save(conversion)).thenReturn(conversion);
        Conversion saved = conversionServicio.guardar(conversion);
        assertNotNull(saved);
        assertEquals(1, saved.getId());
    }

    @Test
    public void testPatchConversion() {
        Conversion conversion = crearConversion();
        Conversion patchData = new Conversion();
        
        Archivo nuevoArchivo = new Archivo();
        nuevoArchivo.setId(2);
        patchData.setArchivoOrigen(nuevoArchivo);

        when(conversionRepositorio.findById(1)).thenReturn(Optional.of(conversion));
        when(conversionRepositorio.save(any(Conversion.class))).thenAnswer(i -> i.getArgument(0));

        Conversion patched = conversionServicio.patchConversion(1, patchData);

        assertNotNull(patched);
        assertEquals(2, patched.getArchivoOrigen().getId());
        verify(conversionRepositorio, times(1)).save(conversion);
    }

    @Test
    public void testEliminar() {
        Conversion conversion = crearConversion();
        when(conversionRepositorio.findById(1)).thenReturn(Optional.of(conversion));
        doNothing().when(conversionRepositorio).delete(conversion);

        conversionServicio.eliminar(1);

        verify(conversionRepositorio, times(1)).delete(conversion);
    }
}
