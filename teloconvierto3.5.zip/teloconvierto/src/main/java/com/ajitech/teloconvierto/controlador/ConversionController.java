package com.ajitech.teloconvierto.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.ajitech.teloconvierto.modelo.Conversion;
import com.ajitech.teloconvierto.servicio.ConversionServicio;

@RestController
@RequestMapping("api/v1/conversiones")

public class ConversionController {

    @Autowired
    private ConversionServicio conversionServicio;

    @GetMapping
    public ResponseEntity<List<Conversion>> getAllConversiones() {
        List<Conversion> conversiones = conversionServicio.listar();
        if (conversiones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(conversiones);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Conversion> getConversionById(@PathVariable Integer id) {
        Conversion conversion = conversionServicio.obtenerPorId(id);
        if (conversion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(conversion);
    }

    @PostMapping
    public ResponseEntity<Conversion> createConversion(@RequestBody Conversion conversion) {
        Conversion creada = conversionServicio.guardar(conversion);
        return ResponseEntity.status(201).body(creada);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Conversion> updateConversion(@PathVariable Integer id, @RequestBody Conversion conversion) {
        Conversion actualizada = conversionServicio.guardar(conversion);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(actualizada);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Conversion> patchConversion(@PathVariable Integer id, @RequestBody Conversion conversion) {
        Conversion actualizada = conversionServicio.patchConversion(id, conversion);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(actualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteConversion(@PathVariable Integer id) {
        Conversion conversion = conversionServicio.obtenerPorId(id);
        if (conversion == null) {
            return ResponseEntity.notFound().build();
        }
        conversionServicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }

//Query
   @GetMapping("/buscarPorUsuarioYFormatoConvertido")
    public ResponseEntity<List<Conversion>> buscarPorUsuarioYFormatoConvertido( @RequestParam String correo, @RequestParam String nombreFormato) {

        List<Conversion> conversiones = conversionServicio.buscarPorUsuarioYFormatoConvertido(correo, nombreFormato);
        if (conversiones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(conversiones);
    }

}
