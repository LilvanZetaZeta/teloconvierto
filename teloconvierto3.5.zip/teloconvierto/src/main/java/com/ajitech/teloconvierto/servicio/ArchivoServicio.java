package com.ajitech.teloconvierto.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajitech.teloconvierto.modelo.Archivo;
import com.ajitech.teloconvierto.repositorio.ArchivoRepositorio;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;

import javax.management.RuntimeErrorException;

@Service
@Transactional
public class ArchivoServicio {
    @Autowired
    private ArchivoRepositorio archivoRepositorio;
    @Autowired
    private ConversionRepositorio conversionRepositorio;

    public List<Archivo> listar() {
        return archivoRepositorio.findAll();
    }

    public Archivo obtenerPorId(Integer id) {
        return archivoRepositorio.findById(id).orElse(null);
    }

    public Archivo guardar(Archivo archivo) {
        return archivoRepositorio.save(archivo);
    }


    public void eliminar(Integer id) {
        Archivo archivo = archivoRepositorio.findById(id)
            .orElseThrow(() -> new RuntimeErrorException("Archivo no encontrado"));
        
        List <Conversion> conversiones = conversionRepositorio.findById(archivo);

        for(Conversion conversion : conversiones){
            conversionRepositorio.deleteByArchivo(conversion);
        }
        archivoRepositorio.delete(archivo);
    }

    public Archivo patchArchivo(Integer id, Archivo archivo){
        Archivo existingArchivo = findById(id);
        if (existingArchivo != null) {
            if(archivo.getNombreArchivo() != null){
                existingArchivo.setNombreArchivo(archivo.getNombreArchivo());
            }
            if(archivo.getFormato() != null){
                existingArchivo.setFormato(archivo.getFormato());
            }
            return save(existingArchivo);
        }
    }

// Metodos del @Query

    public List<Archivo> buscarPorNombreYExtension(String nombre,String extension) {
    return archivoRepositorio.buscarPorNombre(nombre, extension);
    }

    public List<Archivo> buscarPorFormato(Integer formatoId) {
    return archivoRepositorio.buscarPorFormato(formatoId);
    }
}
