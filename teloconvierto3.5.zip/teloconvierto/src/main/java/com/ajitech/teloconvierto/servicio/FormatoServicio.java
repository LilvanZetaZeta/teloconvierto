package com.ajitech.teloconvierto.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajitech.teloconvierto.modelo.Formato;

import com.ajitech.teloconvierto.repositorio.FormatoRepositorio;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class FormatoServicio {
    @Autowired
    private FormatoRepositorio formatoRepositorio;
    @Autowired
    private ArchivoRepositorio ArchivoRepositorio;
    @Autowired
    private ConversionRepositorio ConversionRepositorio;
   
    public List<Formato> listar() {
        return formatoRepositorio.findAll();
    }

    public Formato obtenerPorId(Integer id) {
        return formatoRepositorio.findById(id).orElse(null);
    }

    public Formato guardar(Formato formato) {
        return formatoRepositorio.save(formato);
    }

    public void eliminar(Integer id) {
        Formato formato = formatoRepositorio.findById(id)
            .orElseThrow(() -> new RuntimeException("Formato no encontrado"));

        List<Archivo> archivos = archivoRepositorio.findById(formato);

        for(Archivo archivo : archivos){
            conversionRepositorio.deleteByArchivo(archivo);
            ArchivoRepositorio.delete(archivo);
        }
        formatoRepositorio.delete(formato);
    }

    public Formato patchFormato(Integer id, Formato formato){
        Formato existingFormato = findById(id);
        if (existingFormato != null) {
            if(formato.getNombreFormato() != null){
                existingFormato.setNombreFormato(formato.getNombreFormato());
            }
            if(formato.getExtensionFormato() != null){
                existingFormato.setExtensionFormato(formato.getExtensionFormato());
            }
            return save(existingFormato);
        }
    }
//Metodos del repositorio @Query
    public List<Formato> buscarPorNombre(String nombre) {
        return formatoRepositorio.buscarPorNombre(nombre);
    }

    public List<Formato> buscarPorExtension(String extension) {
        return formatoRepositorio.buscarPorExtension(extension);
    }
}
    



