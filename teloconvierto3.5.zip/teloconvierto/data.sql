 -- FORMATOS
INSERT INTO formato (nombre_formato, extension_formato) VALUES
('PDF', '.pdf'),
('DOCX', '.docx'),
('XLSX', '.xlsx');

-- USUARIOS
INSERT INTO usuario (correo_electronico, nombre_usuario, clave) VALUES
('admin@email.com', 'admin', 'admin123'),
('usuario@email.com', 'usuario1', 'clave123');                      
